<?php
/**
 *
 * Displays portfolio items belonging to specific portfolio categories
 *
 * @package Agile
 * @subpackage Template
 */

get_template_part('loop', 'portfolio');