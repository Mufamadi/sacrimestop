<?php
/**
 * @var $percent
 * @var $title
 */


echo do_shortcode('[piechart percent="' . $percent . '" title="' . $title . '"]');