<?php
/**
 * @var $department
 * @var $type
 */


echo do_shortcode('['. $type .' department="' . $department . '"]');