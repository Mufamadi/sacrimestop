<?php
/**
 * @var $icon
 * @var $title
 * @var $description
 */


echo do_shortcode('[service_item icon="' . $icon . '" title="' . $title . '" description="' . $description . '"]');