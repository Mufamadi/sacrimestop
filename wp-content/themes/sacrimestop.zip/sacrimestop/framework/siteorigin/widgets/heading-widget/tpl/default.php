
<?php
/**
 * @var $style
 * @var $class
 * @var $title
 * @var $pitch_text
 */


echo do_shortcode('[heading2 style="' . $style . '" class="' . $class . '" title="' . $title . '" pitch_text="' . $pitch_text . '"]');

