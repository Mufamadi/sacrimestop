<?php
/**
 * @var $type
 * @var $style
 */


echo do_shortcode('['. $type .' style="' . $style . '" ]');